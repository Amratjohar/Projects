import "./style.css";

function circular(){
return(
<>
  {/* Google Tag Manager (noscript) */}
  {/* <noscript>
    &lt;iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MQ62RMK"
    height="0" width="0"
    style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;
  </noscript> */}
  {/* End Google Tag Manager (noscript) */}
  
  <main className="wrapper bg-lightgrey co-curricular-wrapper">
    <section className="branch-banner cocurricular-banner hideme load-fadein">
      <h1>Co-Curricular</h1>
    </section>
    <section className="intro-txt">
      <div className="container">
        <p>
          <span className="big-alpha">A</span>t Centre Point, we cater to the
          interests, skills and multiple intelligence of our students andequip
          them with life skills, and engage them in various co-curricular
          activities. Students participate in art and craft competitions and
          exhibitions of their artwork are held in the city art galleries.
          Talented and trained faculties mentor students in Performing Arts who
          in turnwin accolades at the local and national level.Our students have
          regularly excelled at the national and international levels invarious
          sports.Day Boardingoffers skill-based activities like Aeromodelling
          and students opt for them to hone their talents and skills to
          perfection.
        </p>
        <p>
          Students get opportunities to participate in Interhouse competitions.
          The Student Council is an elected teamof Captains, Vice Captains and
          Prefects who play a major role in the school.
        </p>
      </div>
    </section>
    <section className="Co-Curricular-main">
      <div className="container">
        <div className="Co-Curricular-content">
          <div className="Co-Curricular-left">
            <div className="visual-art-wrap">
              <h2>
                <span>
                  <img
                    src="images/curricular/visual-art.png"
                    loading="lazy"
                    alt=""
                  />
                </span>{" "}
                Visual Art
              </h2>
              <div className="single-image-carousal owl-carousel">
                <div className="item">
                  <img
                    src="images/curricular/visual-art-1.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
                <div className="item">
                  <img
                    src="images/curricular/visual-art-2.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
              </div>
              <div className="whitebox">
                <p>
                  <span className="big-alpha">A</span>rt and Craft open up a
                  whole new world of color and creativity to the ones blessed
                  with Visual Intelligence. Therefore right from the very young
                  to the seniors, Visual Arts form a regular in the school
                  time-table. Students have won innumerable laurels in national
                  and international scenarios.
                </p>
              </div>
            </div>
            <div className="visual-art-wrap day-boarding">
              <h2>
                <span>
                  <img
                    src="images/curricular/day-boarding.png"
                    loading="lazy"
                    alt=""
                  />
                </span>{" "}
                Day Boarding
              </h2>
              <div className="single-image-carousal owl-carousel">
                <div className="item">
                  <img
                    src="images/curricular/day-boarding-1.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
                <div className="item">
                  <img
                    src="images/curricular/visual-art-1.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
              </div>
              <div className="whitebox">
                <p>
                  <span className="big-alpha">D</span>AY BOARDING is optional
                  and held in the school premises beyond school hours. The
                  objective is to allow students to choose and develop a hobby
                  within safe environs and without more commuting.
                </p>
                <p className="second-p">
                  It greatly helps in personality development.
                </p>
                <ul className="disc-style-list">
                  <li>Commercial Art</li>
                  <li>Photography</li>
                  <li>Screen Printing and batik</li>
                  <li>Hindustani Classical Vocal</li>
                  <li>Keyboard</li>
                  <li>Indian Classical dance: Kathak and Bharatnatyam</li>
                  <li>Martial Arts</li>
                  <li>Basketball</li>
                </ul>
              </div>
            </div>
            <div className="visual-art-wrap Excursions-camps">
              <h2>
                <span>
                  <img
                    src="images/curricular/excursion.png"
                    loading="lazy"
                    alt=""
                  />
                </span>{" "}
                Excursions and Camps
              </h2>
              <div className="">
                <div className="item">
                  <img
                    src="images/curricular/excursion-img.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
              </div>
              <div className="whitebox">
                <p>
                  {" "}
                  <span className="big-alpha">D</span>ay boarders wait for the
                  red letter days when they leave the familiar environs of home
                  and school and spend a few idyllic days in the wild. However
                  it is not all fun and play. Training by experts is imparted to
                  help them learn the tricks of survival, collaborative work,
                  problem solving, etc
                </p>
              </div>
            </div>
          </div>
          <div className="Co-Curricular-right">
            <div className="visual-art-wrap sports-wrap">
              <h2>
                <span>
                  <img
                    src="images/curricular/sport.png"
                    loading="lazy"
                    alt=""
                  />
                </span>{" "}
                Sports
              </h2>
              <div className="">
                <div className="item">
                  <img
                    src="images/curricular/sports-img.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
              </div>
              <div className="whitebox">
                <p>
                  <span className="big-alpha">S</span>ports are a necessary and
                  important component of school upbringing-so feels CPS. Thus
                  the emphasis on Sports is tremendous as a means of all round
                  development of body and mind.
                </p>
                <p className="bold second-p">
                  There have been District, State and National Level achievers.
                  Some players have played International Chess, Skating and Lawn
                  Tennis too.
                </p>
                <p className="second-p">
                  The following facilities are given to all students :
                </p>
                <ul className="disc-style-list">
                  <li>
                    Two swimming pools – a senior pool and a junior paddle pool,
                    complete with a filtration plant
                  </li>
                  <li>Standard size skating rink</li>
                  <li>Basketball courts ·Football field· Lawn Tennis Courts</li>
                  <li>Cricket ground ·Table tennis courts· Badminton Courts</li>
                  <li>200 meter athletic track on 2 acres open ground</li>
                  <li>
                    Play areas with swings, slides and other outdoor equipment
                  </li>
                  <li>
                    Separate, play areas for juniors and seniors ·Martial Arts
                    Zone ·Yoga
                  </li>
                  <li>Chess and Carom room.</li>
                </ul>
              </div>
            </div>
            <div className="visual-art-wrap performing-art-wrap">
              <h2>
                <span>
                  <img
                    src="images/curricular/sport.png"
                    loading="lazy"
                    alt=""
                  />
                </span>{" "}
                Performing Arts
              </h2>
              <div className="">
                <div className="item">
                  <img
                    src="images/curricular/performing-art.jpg"
                    loading="lazy"
                    alt=""
                  />
                </div>
              </div>
              <div className="whitebox">
                <ul className="disc-style-list">
                  <li>
                    Well – equipped music rooms for Western and Indian music
                  </li>
                  <li>Indoor auditoriums &amp; Outdoor amphitheaters</li>
                </ul>
              </div>
            </div>
            <div className="house-wrap">
              <h2>House</h2>
              <p>
                <span className="big-alpha">T</span>o encourage the spirit of
                healthy competition, the student body is divided into four
                Houses as Red, Green, Blue and Yellow. The Students’ Council
                comprises the House Captains, Vice Captains, and Prefects.
              </p>
              <p>
                They are led by the School Captain and School Vice Captain. The
                Students’ Council meets regularly to discuss school issues and
                have a major say in the running of the school.
              </p>
              <p>
                There are regular Inter-House Competitions which are keenly
                contested. These include varied activities such as Performing
                and Visual Arts, Sports, etc including
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section className="house-carousal-wrap">
      <div className="container">
        <div className="">
          <div className="item">
            <img
              src="images/curricular/house-carousal-1.jpg"
              loading="lazy"
              alt=""
            />
          </div>
          {/* <div class="item">

                  <img src="images/curricular/house-carousal-1.jpg" alt="">

              </div>

              <div class="item">

                  <img src="images/curricular/house-carousal-1.jpg" alt="">

              </div> */}
        </div>
      </div>
    </section>
    {/* admission section */}
    <section className="admission-wrap">
      <div className="container">
        <h2 className="hideme slide-to-top">For New Admissions</h2>
        <div className="adm-process-wrap">
          <div className="admission-box hideme slide-to-top delay1">
            <a
              href="https://centrepointschools.com/admission-application/"
              target="_blank"
            >
              <img src="images/admission-enq-icon.png" loading="lazy" alt="" />
              <span>Enquire Now</span>
            </a>
          </div>
          <div className="admission-box admission-box__contact hideme slide-to-top delay3">
            <img src="images/admission-open-icon.png" loading="lazy" alt="" />
            {/* <span>
              <a
                href="tel:+7122581742"
                onclick="ga('send', 'event', { eventCategory: 'Call', eventAction: 'Click', eventLabel: 'Call'});"
              >
                (+91) 7122581742
              </a>
              <a
                href="mail:cpskr@centrepointschools.com"
                onclick="ga('send', 'event', { eventCategory: 'Email', eventAction: 'Click', eventLabel: 'Call'});"
              >
                cpskr@centrepointschools.com
              </a>
            </span> */}
          </div>
        </div>
      </div>
    </section>
  </main>
</>
);
}

export default circular;